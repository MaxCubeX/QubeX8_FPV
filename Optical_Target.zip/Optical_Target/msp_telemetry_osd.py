import serial
import struct
import pygame

# Налаштування Pygame
pygame.init()
hud_width = 640
hud_height = 480
screen = pygame.display.set_mode((hud_width, hud_height))
pygame.display.set_caption("FPV MSP Telemetry OSD")
black = (0, 0, 0)
green = (0, 255, 0)
red = (255, 0, 0)

# Налаштування шрифту
font = pygame.font.Font(None, 30)

# Налаштування Serial для MSP
ser = None
try:
    ser = serial.Serial('/dev/ttyAMA0', 115200)
    print("Serial порт відкрито.")
except serial.SerialException as e:
    print(f"ПОМИЛКА: Відкриття Serial порту: {e}")
    msp_connected = False
else:
    msp_connected = True

def send_msp_request(command_id):
    if not ser:
        return
    header = b'$M<'
    length = 0
    command = command_id.to_bytes(1, 'little')
    checksum = length ^ command_id
    request = header + length.to_bytes(1, 'little') + command + checksum.to_bytes(1, 'little')
    try:
        ser.write(request)
    except serial.SerialException as e:
        print(f"ПОМИЛКА: Надсилання MSP запиту: {e}")

def parse_msp_response(data):
    if len(data) < 5 or data[0:3] != b'$M>':
        return None, None
    length = data[3]
    command = data[4]
    payload = data[5:-1]
    checksum_received = data[-1]

    checksum_calculated = 0
    checksum_calculated ^= length
    checksum_calculated ^= command
    for byte in payload:
        checksum_calculated ^= byte

    if checksum_calculated == checksum_received:
        return command, payload
    else:
        print(f"ПОМИЛКА: Неправильна контрольна сума MSP відповіді.")
        return None, None

last_telemetry_request_time = 0
telemetry_request_interval = 0.5
voltage = 0
altitude = 0

def update_telemetry():
    global last_telemetry_request_time, voltage, altitude
    if not ser:
        return
    current_time = pygame.time.get_ticks() / 1000.0
    if current_time - last_telemetry_request_time >= telemetry_request_interval:
        send_msp_request(110) # MSP_VOLTAGE
        send_msp_request(109) # MSP_ALTITUDE
        last_telemetry_request_time = current_time

    if ser.in_waiting > 0:
        try:
            msp_data = ser.read(ser.in_waiting)
            command_id, payload = parse_msp_response(msp_data)
            if command_id == 110 and payload is not None and len(payload) >= 2:
                voltage = struct.unpack('<H', payload[0:2])[0] / 10.0
            elif command_id == 109 and payload is not None and len(payload) >= 4:
                altitude = struct.unpack('<i', payload[0:4])[0] / 100.0
        except serial.SerialException as e:
            print(f"ПОМИЛКА: Помилка читання з Serial порту: {e}")

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    screen.fill(black)

    # Відображення статусу з'єднання MSP
    if msp_connected:
        text_surface = font.render("З'єднання встановлено! [OK]", True, green)
    else:
        text_surface = font.render("З'єднання відсутнє! [ERROR]", True, red)
    screen.blit(text_surface, (10, 10))

    # Оновлення та відображення телеметрії
    update_telemetry()
    text_surface = font.render(f"Напруга: {voltage:.1f}V", True, green)
    screen.blit(text_surface, (10, 50))
    text_surface = font.render(f"Висота: {altitude:.1f}м", True, green)
    screen.blit(text_surface, (10, 90))

    pygame.display.flip()

if ser:
    ser.close()
pygame.quit()
