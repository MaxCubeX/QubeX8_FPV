import cv2
import pygame

# Налаштування Pygame
pygame.init()
hud_width = 640
hud_height = 480
screen = pygame.display.set_mode((hud_width, hud_height))
pygame.display.set_caption("FPV Video Output")
black = (0, 0, 0)

# Налаштування камери OpenCV
try:
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        raise IOError("Не вдалося відкрити вебкамеру")
    print("Камеру відкрито.")
except IOError as e:
    print(f"ПОМИЛКА: Відкриття камери: {e}")
    exit()

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    ret, frame = cap.read()
    if not ret:
        print("Помилка отримання кадру")
        break

    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    frame_pygame = pygame.surfarray.make_surface(frame_rgb)
    screen.fill(black)
    screen.blit(pygame.transform.scale(frame_pygame, (hud_width, hud_height)), (0, 0))

    pygame.display.flip()

cap.release()
pygame.quit()
