import serial
import struct
import time

# Налаштування Serial для MSP
ser = None
try:
    ser = serial.Serial('/dev/ttyAMA0', 115200)
    print("Serial порт відкрито для автопілота.")
except serial.SerialException as e:
    print(f"ПОМИЛКА (Автопілот): Відкриття Serial порту: {e}")
    autopilot_enabled = False
else:
    autopilot_enabled = True

def send_msp_request(command_id):
    if not ser or not autopilot_enabled:
        return None
    header = b'$M<'
    length = 0
    command = command_id.to_bytes(1, 'little')
    checksum = length ^ command_id
    request = header + length.to_bytes(1, 'little') + command + checksum.to_bytes(1, 'little')
    try:
        ser.write(request)
    except serial.SerialException as e:
        print(f"ПОМИЛКА (Автопілот): Надсилання MSP запиту: {e}")
    return None

def send_msp_set_raw_rc(channels):
    if not ser or not autopilot_enabled:
        return
    header = b'$M<'
    length = 16
    command = 200  # MSP_SET_RAW_RC
    payload = struct.pack('<HHHHHHHH', *channels)
    checksum = length ^ command
    for byte in payload:
        checksum ^= byte
    request = header + length.to_bytes(1, 'little') + command.to_bytes(1, 'little') + payload + checksum.to_bytes(1, 'little')
    try:
        ser.write(request)
    except serial.SerialException as e:
        print(f"ПОМИЛКА (Автопілот): Надсилання MSP команди: {e}")

def parse_msp_response(data):
    if len(data) < 5 or data[0:3] != b'$M>':
        return None, None
    length = data[3]
    command = data[4]
    payload = data[5:-1]
    checksum_received = data[-1]

    checksum_calculated = 0
    checksum_calculated ^= length
    checksum_calculated ^= command
    for byte in payload:
        checksum_calculated ^= byte

    if checksum_calculated == checksum_received:
        return command, payload
    else:
        print(f"ПОМИЛКА (Автопілот): Неправильна контрольна сума MSP відповіді.")
        return None, None

def get_altitude():
    if not ser or not autopilot_enabled:
        return None
    send_msp_request(109) # MSP_ALTITUDE
    start_time = time.time()
    while time.time() - start_time < 0.1: # Чекаємо коротку відповідь
        if ser.in_waiting > 0:
            try:
                msp_data = ser.read(ser.in_waiting)
                command_id, payload = parse_msp_response(msp_data)
                if command_id == 109 and payload is not None and len(payload) >= 4:
                    return struct.unpack('<i', payload[0:4])[0] / 100.0
            except serial.SerialException as e:
                print(f"ПОМИЛКА (Автопілот): Помилка читання з Serial порту: {e}")
                return None
    return None

def get_imu():
    if not ser or not autopilot_enabled:
        return None
    send_msp_request(102) # MSP_RAW_IMU
    start_time = time.time()
    while time.time() - start_time < 0.1: # Чекаємо коротку відповідь
        if ser.in_waiting > 0:
            try:
                msp_data = ser.read(ser.in_waiting)
                command_id, payload = parse_msp_response(msp_data)
                if command_id == 102 and payload is not None and len(payload) >= 18:
                    accX, accY, accZ, gyroX, gyroY, gyroZ = struct.unpack('<hhhhhhhhh', payload[0:18])
                    return {"acc": (accX, accY, accZ), "gyro": (gyroX, gyroY, gyroZ)}
            except serial.SerialException as e:
                print(f"ПОМИЛКА (Автопілот): Помилка читання IMU: {e}")
                return None
    return None

def autopilot_control():
    target_altitude = 1.0 # Зафіксована висота (в метрах)
    altitude_pid_kp = 1.0
    altitude_pid_ki = 0.0
    altitude_pid_kd = 0.0
    altitude_integral = 0.0
    altitude_last_error = 0.0

    roll_pid_kp = 0.1
    roll_pid_ki = 0.0
    roll_pid_kd = 0.0
    roll_integral = 0.0
    roll_last_error = 0.0

    pitch_pid_kp = 0.1
    pitch_pid_ki = 0.0
    pitch_pid_kd = 0.0
    pitch_integral = 0.0
    pitch_last_error = 0.0

    while autopilot_enabled:
        current_altitude = get_altitude()
        imu_data = get_imu()

        throttle_rc = 1500
        roll_rc = 1500
        pitch_rc = 1500

        if current_altitude is not None:
            altitude_error = target_altitude - current_altitude
            altitude_integral += altitude_error
            altitude_derivative = altitude_error - altitude_last_error
            altitude_output = altitude_pid_kp * altitude_error + altitude_pid_ki * altitude_integral + altitude_pid_kd * altitude_derivative
            throttle_rc += int(altitude_output * 50)
            throttle_rc = max(1000, min(2000, throttle_rc))
            altitude_last_error = altitude_error

        if imu_data:
            accX, accY, accZ = imu_data["acc"]
            # Просте визначення кутів крену та тангажу на основі акселерометра (спрощено)
            roll_angle = np.arctan2(accY, np.sqrt(accX**2 + accZ**2))
            pitch_angle = np.arctan2(-accX, accZ)

            # PID регулювання крену
            target_roll_angle = 0 # Утримуємо горизонтальне положення
            roll_error = target_roll_angle - roll_angle
            roll_integral += roll_error
            roll_derivative = roll_error - roll_last_error
            roll_output = roll_pid_kp * roll_error + roll_pid_ki * roll_integral + roll_pid_kd * roll_derivative
            roll_rc += int(roll_output * 200)
            roll_rc = max(1000, min(2000, roll_rc))
            roll_last_error = roll_error

            # PID регулювання тангажу
            target_pitch_angle = 0 # Утримуємо горизонтальне положення
            pitch_error = target_pitch_angle - pitch_angle
            pitch_integral += pitch_error
            pitch_derivative = pitch_error - pitch_last_error
            pitch_output = pitch_pid_kp * pitch_error + pitch_pid_ki * pitch_integral + pitch_pid_kd * pitch_derivative
            pitch_rc += int(pitch_output * 200)
            pitch_rc = max(1000, min(2000, pitch_rc))
            pitch_last_error = pitch_error

        # Припускаємо, що канал Yaw утримується в середині
        rc_channels = [roll_rc, pitch_rc, throttle_rc, 1500, 1500, 1500, 1500, 1500]
        send_msp_set_raw_rc(rc_channels)

        time.sleep(0.01) # Менша затримка для більш швидкого реагування

if __name__ == "__main__":
    import numpy as np # Імпортуємо numpy тут, щоб уникнути помилок при імпорті в основному файлі, якщо він не використовується
    if autopilot_enabled:
        print("Автопілот активовано.")
        autopilot_control()
    else:
        print("Автопілот не активовано через помилку Serial порту.")
