import cv2
import pygame
import numpy as np

# Налаштування Pygame
pygame.init()
hud_width = 640
hud_height = 480
screen = pygame.display.set_mode((hud_width, hud_height))
pygame.display.set_caption("FPV Object Tracking OSD")
black = (0, 0, 0)
green = (0, 255, 0)

# Налаштування шрифту
font = pygame.font.Font(None, 30)

# Налаштування камери OpenCV
try:
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        raise IOError("Не вдалося відкрити вебкамеру")
    print("Камеру відкрито.")
except IOError as e:
    print(f"ПОМИЛКА: Відкриття камери: {e}")
    exit()

def detect_movement(frame1, frame2, threshold=25, sensitivity=10):
    diff = cv2.absdiff(frame1, frame2)
    gray_diff = cv2.cvtColor(diff, cv2.COLOR_BGR2GRAY)
    blur_diff = cv2.GaussianBlur(gray_diff, (5, 5), 0)
    _, thresh_diff = cv2.threshold(blur_diff, threshold, 255, cv2.THRESH_BINARY)
    contours, _ = cv2.findContours(thresh_diff, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if len(contours) > sensitivity:
        return True, contours
    return False, []

running = True
prev_frame = None
target_detected = False
target_rect = None

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    ret, frame = cap.read()
    if not ret:
        print("Помилка отримання кадру")
        break

    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    frame_pygame = pygame.surfarray.make_surface(frame_rgb)
    screen.fill(black)
    screen.blit(pygame.transform.scale(frame_pygame, (hud_width, hud_height)), (0, 0))

    if prev_frame is not None:
        movement_detected, contours = detect_movement(prev_frame, frame)
        if movement_detected:
            largest_contour = max(contours, key=cv2.contourArea)
            x, y, w, h = cv2.boundingRect(largest_contour)
            target_rect = (x, y, w, h)
            target_detected = True
        else:
            target_detected = False
            target_rect = None

    if target_detected and target_rect:
        pygame.draw.rect(screen, green, target_rect, 2)

    pygame.display.flip()
    prev_frame = frame.copy()

cap.release()
pygame.quit()
