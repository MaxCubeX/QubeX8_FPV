#!/bin/bash -x

# Перевірка на root права
if [ "$EUID" -ne 0 ]; then
  echo "ПОМИЛКА: Будь ласка, запустіть скрипт від імені root (sudo)."
  exit 1
fi

echo "DEBUG: Розпочинаємо встановлення необхідних компонентів для системи FPV дрона..."

# Оновлення списку пакетів
echo "DEBUG: Оновлюємо список пакетів..."
sudo apt update
if [ "$?" -ne 0 ]; then
  echo "ПОМИЛКА: Не вдалося оновити список пакетів."
  exit 1
fi
echo "DEBUG: Список пакетів оновлено."

# Встановлення Python3 та pip (якщо ще не встановлено)
echo "DEBUG: Перевіряємо встановлення Python3 та pip..."
command -v python3 >/dev/null 2>&1 || {
  echo "DEBUG: Встановлюємо Python3..."
  sudo apt install -y python3 python3-pip
  if [ "$?" -ne 0 ]; then
    echo "ПОМИЛКА: Не вдалося встановити Python3."
    exit 1
  fi
  echo "DEBUG: Python3 встановлено."
}
command -v pip3 >/dev/null 2>&1 || {
  echo "DEBUG: Встановлюємо pip3..."
  sudo apt install -y python3-pip
  if [ "$?" -ne 0 ]; then
    echo "ПОМИЛКА: Не вдалося встановити pip3."
    exit 1
  fi
  echo "DEBUG: pip3 встановлено."
}
echo "DEBUG: Python3 та pip3 доступні."

# Встановлення необхідних бібліотек Python
echo "DEBUG: Встановлюємо необхідні бібліотеки Python (pygame, opencv-python, pyserial, numpy)..."
sudo apt install python3-venv
python3 -m venv myenv
source myenv/bin/activate
pip install pygame opencv-python pyserial numpy
if [ "$?" -ne 0 ]; then
  echo "ПОМИЛКА: Не вдалося встановити бібліотеки Python."
  exit 1
fi
echo "DEBUG: Бібліотеки Python встановлено."

# Встановлення шрифтів (якщо потрібно)
echo "DEBUG: Встановлюємо додаткові шрифти (freefont-ttf)..."
sudo apt install -y fonts-freefont-ttf
if [ "$?" -ne 0 ]; then
  echo "ПОМИЛКА: Не вдалося встановити додаткові шрифти."
fi
echo "DEBUG: Додаткові шрифти встановлено (або вже були встановлені)."

# Налаштування Serial порту (якщо потрібно)
echo "DEBUG: Налаштовуємо Serial порт..."
sudo systemctl stop serial-getty@ttyAMA0.service
sudo systemctl disable serial-getty@ttyAMA0.service
sudo sed -i 's/console=serial0,115200 //' /boot/cmdline.txt
sudo sed -i 's/console=ttyS0,115200 //' /boot/cmdline.txt
echo "enable_uart=1" | sudo tee -a /boot/config.txt
echo "DEBUG: Serial порт налаштовано. Перезавантажте Raspberry Pi для застосування змін."

echo "DEBUG: Створюємо директорію для проєкту (якщо не існує)..."
PROJECT_DIR="fpv_auto_aim"
mkdir -p "$PROJECT_DIR"
cd "$PROJECT_DIR"
echo "DEBUG: Перейшли до директорії проєкту: $PROJECT_DIR"

echo "DEBUG: Копіюємо файли проєкту..."
# Припустімо, що скрипт install_auto_aim.sh знаходиться на рівень вище за директорію проєкту
cp ../camera_output.py .
cp ../object_tracking_osd.py .
cp ../msp_telemetry_osd.py .
cp ../autopilot.py .
cp ../target_sprite.png .
echo "DEBUG: Файли проєкту скопійовано."

echo "DEBUG: Створюємо файли служб systemd для автозапуску..."
cat <<EOF | sudo tee camera_output.service
[Unit]
Description=Автозапуск скрипта виведення відео
After=network.target

[Service]
User=pi
WorkingDirectory=/home/pi/$PROJECT_DIR
ExecStart=/usr/bin/python3 /home/pi/$PROJECT_DIR/camera_output.py
Restart=on-failure
StandardOutput=append:/home/pi/$PROJECT_DIR/camera_output.log
StandardError=append:/home/pi/$PROJECT_DIR/camera_error.log

[Install]
WantedBy=multi-user.target
EOF

cat <<EOF | sudo tee object_tracking_osd.service
[Unit]
Description=Автозапуск скрипта відстеження об'єктів та OSD
After=network.target

[Service]
User=pi
WorkingDirectory=/home/pi/$PROJECT_DIR
ExecStart=/usr/bin/python3 /home/pi/$PROJECT_DIR/object_tracking_osd.py
Restart=on-failure
StandardOutput=append:/home/pi/$PROJECT_DIR/object_tracking_osd.log
StandardError=append:/home/pi/$PROJECT_DIR/object_tracking_error.log

[Install]
WantedBy=multi-user.target
EOF

cat <<EOF | sudo tee msp_telemetry_osd.service
[Unit]
Description=Автозапуск скрипта MSP телеметрії та OSD
After=network.target

[Service]
User=pi
WorkingDirectory=/home/pi/$PROJECT_DIR
ExecStart=/usr/bin/python3 /home/pi/$PROJECT_DIR/msp_telemetry_osd.py
Restart=on-failure
StandardOutput=append:/home/pi/$PROJECT_DIR/msp_telemetry_osd.log
StandardError=append:/home/pi/$PROJECT_DIR/msp_telemetry_error.log

[Install]
WantedBy=multi-user.target
EOF

cat <<EOF | sudo tee autopilot.service
[Unit]
Description=Автозапуск скрипта автопілота
After=network.target

[Service]
User=pi
WorkingDirectory=/home/pi/$PROJECT_DIR
ExecStart=/usr/bin/python3 /home/pi/$PROJECT_DIR/autopilot.py
Restart=on-failure
StandardOutput=append:/home/pi/$PROJECT_DIR/autopilot.log
StandardError=append:/home/pi/$PROJECT_DIR/autopilot_error.log

[Install]
WantedBy=multi-user.target
EOF

echo "DEBUG: Файли служб systemd створено."

echo "DEBUG: Встановлення завершено. Будь ласка, перезавантажте Raspberry Pi для застосування змін Serial порту."
echo "DEBUG: Після перезавантаження ви можете увімкнути автозапуск служб командою:"
echo "sudo systemctl enable camera_output.service"
echo "sudo systemctl enable object_tracking_osd.service"
echo "sudo systemctl enable msp_telemetry_osd.service"
echo "sudo systemctl enable autopilot.service"
echo "DEBUG: та запустити їх вручну командою:"
echo "sudo systemctl start camera_output.service"
echo "sudo systemctl start object_tracking_osd.service"
echo "sudo systemctl start msp_telemetry_osd.service"
echo "sudo systemctl start autopilot.service"
exit 0
